class pkt_scb extends uvm_scoreboard;
  `uvm_component_utils(pkt_scb)

  uvm_analysis_imp #(apb_seq_item, pkt_scb) apb_imp;

  // Shadow state modeled in Scoreboard
  bit        ref_locked;
  bit [31:0] ref_switch_ctrl;
  bit [3:0]  ref_port_en;
  bit [3:0]  ref_fwd_en;
  bit [31:0] ref_gen_pkt_cfg;
  bit [15:0] ref_gen_interval;
  bit [15:0] ref_gen_count;
  int        total_txns;
  int        error_count;

  function new(string name = "pkt_scb", uvm_component parent = null);
    super.new(name, parent);
    apb_imp = new("apb_imp", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    reset_ref_model();
  endfunction

  function void reset_ref_model();
    ref_locked       = 1'b1;
    ref_switch_ctrl  = 32'h0;
    ref_port_en      = RST_PORT_ENABLE[3:0];
    ref_fwd_en       = RST_FWD_ENABLE[3:0];
    ref_gen_pkt_cfg  = RST_GEN_PKT_CFG;
    ref_gen_interval = RST_GEN_INTERVAL[15:0];
    ref_gen_count    = RST_GEN_COUNT[15:0];
  endfunction

  virtual function void write(apb_seq_item tr);
    bit exp_slverr;
    total_txns++;

    // 1. Check PSLVERR accuracy (unaligned or > ADDR_MAX)
    exp_slverr = (|tr.addr[1:0]) || (tr.addr > ADDR_MAX);
    if (tr.slverr !== exp_slverr) begin
      `uvm_error("SCB_SLVERR", $sformatf("Addr=0x%04h: Exp PSLVERR=%0b, Got=%0b",
                 tr.addr, exp_slverr, tr.slverr))
      error_count++;
    end

    if (exp_slverr) begin
      if (!tr.write && tr.data !== 32'h0) begin
        `uvm_error("SCB_RDATA", $sformatf("Invalid read at 0x%04h must return 0, got 0x%08h",
                   tr.addr, tr.data))
        error_count++;
      end
      return;
    end

    // 2. Update/Check Reference CSR State on Valid Transfers
    if (tr.write) begin
      case (tr.addr)
        ADDR_SOFT_RESET: begin
          if (tr.data[0]) reset_ref_model();
        end
        ADDR_LOCK: begin
          ref_locked = (tr.data != UNLOCK_KEY);
        end
        ADDR_SWITCH_CTRL:  if (!ref_locked) ref_switch_ctrl = tr.data & MASK_SWITCH_CTRL;
        ADDR_PORT_ENABLE:  if (!ref_locked) ref_port_en     = tr.data[3:0];
        ADDR_FWD_ENABLE:   if (!ref_locked) ref_fwd_en      = tr.data[3:0];
        ADDR_GEN_PKT_CFG:  if (!ref_locked) begin
          ref_gen_pkt_cfg = tr.data & MASK_GEN_PKT_CFG;
          if (tr.data[15:8] == 8'd0) ref_gen_pkt_cfg[15:8] = 8'd1;
        end
        ADDR_GEN_INTERVAL: if (!ref_locked) ref_gen_interval = tr.data[15:0];
        ADDR_GEN_COUNT:    if (!ref_locked) ref_gen_count    = tr.data[15:0];
        default: ;
      endcase
    end else begin
      // Check Readback Data on Static/Configuration Registers
      case (tr.addr)
        ADDR_DEVICE_ID:    check_val("DEVICE_ID",    tr.data, RST_DEVICE_ID);
        ADDR_VERSION:      check_val("VERSION",      tr.data, RST_VERSION);
        ADDR_SWITCH_CTRL:  check_val("SWITCH_CTRL",  tr.data, ref_switch_ctrl);
        ADDR_PORT_ENABLE:  check_val("PORT_ENABLE",  tr.data, {28'h0, ref_port_en});
        ADDR_FWD_ENABLE:   check_val("FWD_ENABLE",   tr.data, {28'h0, ref_fwd_en});
        ADDR_GEN_PKT_CFG:  check_val("GEN_PKT_CFG",  tr.data, ref_gen_pkt_cfg);
        ADDR_GEN_INTERVAL: check_val("GEN_INTERVAL", tr.data, {16'h0, ref_gen_interval});
        ADDR_GEN_COUNT:    check_val("GEN_COUNT",    tr.data, {16'h0, ref_gen_count});
        ADDR_LOCK:         check_val("LOCK",         tr.data, {31'h0, ref_locked});
        ADDR_IRQ_FORCE,
        ADDR_ERR_INJECT,
        ADDR_SOFT_RESET:   check_val("WO_REG_ZERO",  tr.data, 32'h0);
        default: ;
      endcase
    end
  endfunction

  function void check_val(string reg_name, logic [31:0] act, logic [31:0] exp);
    if (act !== exp) begin
      `uvm_error("SCB_MISMATCH", $sformatf("%s read mismatch: Exp=0x%08h, Got=0x%08h",
                 reg_name, exp, act))
      error_count++;
    end else begin
      `uvm_info("SCB_MATCH", $sformatf("%s verified: 0x%08h", reg_name, act), UVM_HIGH)
    end
  endfunction

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("SCB_SUMMARY", $sformatf("Total APB Transactions=%0d, Scoreboard Errors=%0d",
              total_txns, error_count), UVM_LOW)
  endfunction
endclass
