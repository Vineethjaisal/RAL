class apb_monitor extends uvm_monitor;
  `uvm_component_utils(apb_monitor)

  virtual apb_if                  vif;
  uvm_analysis_port #(apb_seq_item) item_collected_port;

  function new(string name = "apb_monitor", uvm_component parent = null);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("MON_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    @(posedge vif.presetn);
    forever begin
      @(posedge vif.pclk);
      if (vif.psel && vif.penable && vif.pready) begin
        apb_seq_item tr = apb_seq_item::type_id::create("tr");
        tr.addr   = vif.paddr;
        tr.write  = vif.pwrite;
        tr.data   = vif.pwrite ? vif.pwdata : vif.prdata;
        tr.slverr = vif.pslverr;
        tr.irq    = vif.irq;
        item_collected_port.write(tr);
      end
    end
  endtask
endclass
