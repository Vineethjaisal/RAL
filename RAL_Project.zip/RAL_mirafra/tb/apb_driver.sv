class apb_driver extends uvm_driver #(apb_seq_item);
  `uvm_component_utils(apb_driver)

  virtual apb_if vif;

  function new(string name = "apb_driver", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("DRV_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    vif.psel    <= 1'b0;
    vif.penable <= 1'b0;
    vif.pwrite  <= 1'b0;
    vif.paddr   <= '0;
    vif.pwdata  <= '0;

    @(posedge vif.presetn);
    @(posedge vif.pclk);

    forever begin
      seq_item_port.get_next_item(req);
      drive_transfer(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_transfer(apb_seq_item tr);
    // Setup Phase
    @(posedge vif.pclk);
    vif.psel    <= 1'b1;
    vif.penable <= 1'b0;
    vif.pwrite  <= tr.write;
    vif.paddr   <= tr.addr;
    vif.pwdata  <= tr.write ? tr.data : '0;

    // Access Phase
    @(posedge vif.pclk);
    vif.penable <= 1'b1;

    // Wait for PREADY
    do begin
      @(posedge vif.pclk);
    end while (!vif.pready);

    // Sample outputs at end of Access Phase
    if (!tr.write) begin
      tr.data = vif.prdata;
    end
    tr.slverr = vif.pslverr;
    tr.irq    = vif.irq;

    // Return to Idle
    vif.psel    <= 1'b0;
    vif.penable <= 1'b0;
    vif.pwrite  <= 1'b0;
  endtask
endclass

