module tb;
  logic pclk;
  logic presetn;

  // 100 MHz Clock Generator
  initial begin
    pclk = 1'b0;
    forever #5 pclk = ~pclk;
  end

  // Active-Low Asynchronous Reset
  initial begin
    presetn = 1'b0;
    repeat (5) @(posedge pclk);
    presetn = 1'b1;
  end

  // APB Interface
  apb_if vif(pclk, presetn);

  // DUT Instance (named `dut` to match HDL root path `tb.dut`)
  apb_pkt_switch dut (
    .pclk    (pclk),
    .presetn (presetn),
    .psel    (vif.psel),
    .penable (vif.penable),
    .pwrite  (vif.pwrite),
    .paddr   (vif.paddr),
    .pwdata  (vif.pwdata),
    .prdata  (vif.prdata),
    .pready  (vif.pready),
    .pslverr (vif.pslverr),
    .irq     (vif.irq)
  );

  initial begin
    uvm_config_db#(virtual apb_if)::set(null, "*", "vif", vif);
    run_test();
  end
	initial begin 
	//#1000;
	//$finish;
	end
endmodule
