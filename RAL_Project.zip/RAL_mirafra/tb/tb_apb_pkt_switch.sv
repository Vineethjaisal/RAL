// -----------------------------------------------------------------------------
// tb/tb_apb_pkt_switch.sv
// Complete UVM Verification Environment & Directed/RAL Testbench
// Includes: Interface, Driver, Monitor, Sequencer, Agent, Scoreboard,
//           Functional Coverage Collector, Predictor, Environment,
//           Sequences, Tests, and Top Module.
// -----------------------------------------------------------------------------
`timescale 1ns/1ps

import uvm_pkg::*;
import apb_pkt_pkg::*;
import pkt_ral_pkg::*;
`include "uvm_macros.svh"

// =============================================================================
// 1. APB3 Interface
// =============================================================================
interface apb_if(input logic pclk, input logic presetn);
  logic              psel;
  logic              penable;
  logic              pwrite;
  logic [ADDR_W-1:0] paddr;
  logic [DATA_W-1:0] pwdata;
  logic [DATA_W-1:0] prdata;
  logic              pready;
  logic              pslverr;
  logic              irq;
endinterface

// =============================================================================
// 2. APB Sequencer
// =============================================================================
class apb_sequencer extends uvm_sequencer #(apb_seq_item);
  `uvm_component_utils(apb_sequencer)

  function new(string name = "apb_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass

// =============================================================================
// 3. APB Driver
// =============================================================================
class apb_driver extends uvm_driver #(apb_seq_item);
  `uvm_component_utils(apb_driver)

  virtual apb_if vif;

  function new(string name = "apb_driver", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("DRV_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    vif.psel    <= 1'b0;
    vif.penable <= 1'b0;
    vif.pwrite  <= 1'b0;
    vif.paddr   <= '0;
    vif.pwdata  <= '0;

    @(posedge vif.presetn);
    @(posedge vif.pclk);

    forever begin
      seq_item_port.get_next_item(req);
      drive_transfer(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_transfer(apb_seq_item tr);
    // Setup Phase
    @(posedge vif.pclk);
    vif.psel    <= 1'b1;
    vif.penable <= 1'b0;
    vif.pwrite  <= tr.write;
    vif.paddr   <= tr.addr;
    vif.pwdata  <= tr.write ? tr.data : '0;

    // Access Phase
    @(posedge vif.pclk);
    vif.penable <= 1'b1;

    // Wait for PREADY
    do begin
      @(posedge vif.pclk);
    end while (!vif.pready);

    // Sample data at end of Access Phase
    if (!tr.write) begin
      tr.data = vif.prdata;
    end
    tr.slverr = vif.pslverr;
    tr.irq    = vif.irq;

    // Return to Idle
    vif.psel    <= 1'b0;
    vif.penable <= 1'b0;
    vif.pwrite  <= 1'b0;
  endtask
endclass

// =============================================================================
// 4. APB Monitor
// =============================================================================
class apb_monitor extends uvm_monitor;
  `uvm_component_utils(apb_monitor)

  virtual apb_if                    vif;
  uvm_analysis_port #(apb_seq_item) item_collected_port;

  function new(string name = "apb_monitor", uvm_component parent = null);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("MON_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    @(posedge vif.presetn);
    forever begin
      @(posedge vif.pclk);
      if (vif.psel && vif.penable && vif.pready) begin
        apb_seq_item tr = apb_seq_item::type_id::create("tr");
        tr.addr   = vif.paddr;
        tr.write  = vif.pwrite;
        tr.data   = vif.pwrite ? vif.pwdata : vif.prdata;
        tr.slverr = vif.pslverr;
        tr.irq    = vif.irq;
        item_collected_port.write(tr);
      end
    end
  endtask
endclass

// =============================================================================
// 5. APB Agent
// =============================================================================
class apb_agent extends uvm_agent;
  `uvm_component_utils(apb_agent)

  apb_sequencer sqr;
  apb_driver    drv;
  apb_monitor   mon;

  function new(string name = "apb_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    mon = apb_monitor::type_id::create("mon", this);
    if (get_is_active() == UVM_ACTIVE) begin
      sqr = apb_sequencer::type_id::create("sqr", this);
      drv = apb_driver   ::type_id::create("drv", this);
    end
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (get_is_active() == UVM_ACTIVE) begin
      drv.seq_item_port.connect(sqr.seq_item_export);
    end
  endfunction
endclass

// =============================================================================
// 6. Scoreboard (`pkt_scb`)
// =============================================================================
class pkt_scb extends uvm_scoreboard;
  `uvm_component_utils(pkt_scb)

  uvm_analysis_imp #(apb_seq_item, pkt_scb) apb_imp;

  bit        ref_locked;
  bit [31:0] ref_switch_ctrl;
  bit [3:0]  ref_port_en;
  bit [3:0]  ref_fwd_en;
  bit [31:0] ref_gen_pkt_cfg;
  bit [15:0] ref_gen_interval;
  bit [15:0] ref_gen_count;
  int        total_txns;
  int        error_count;

  function new(string name = "pkt_scb", uvm_component parent = null);
    super.new(name, parent);
    apb_imp = new("apb_imp", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    reset_ref_model();
  endfunction

  function void reset_ref_model();
    ref_locked       = 1'b1;
    ref_switch_ctrl  = 32'h0;
    ref_port_en      = RST_PORT_ENABLE[3:0];
    ref_fwd_en       = RST_FWD_ENABLE[3:0];
    ref_gen_pkt_cfg  = RST_GEN_PKT_CFG;
    ref_gen_interval = RST_GEN_INTERVAL[15:0];
    ref_gen_count    = RST_GEN_COUNT[15:0];
  endfunction

  virtual function void write(apb_seq_item tr);
    bit exp_slverr;
    total_txns++;

    // 1. Check PSLVERR condition: unaligned or > ADDR_MAX
    exp_slverr = (|tr.addr[1:0]) || (tr.addr > ADDR_MAX);
    if (tr.slverr !== exp_slverr) begin
      `uvm_error("SCB_SLVERR", $sformatf("Addr=0x%04h: Expected PSLVERR=%0b, Got=%0b",
                 tr.addr, exp_slverr, tr.slverr))
      error_count++;
    end

    if (exp_slverr) begin
      if (!tr.write && tr.data !== 32'h0) begin
        `uvm_error("SCB_RDATA", $sformatf("Invalid read at 0x%04h must return 0, got 0x%08h",
                   tr.addr, tr.data))
        error_count++;
      end
      return;
    end

    // 2. Track reference state
    if (tr.write) begin
      case (tr.addr)
        ADDR_SOFT_RESET:   if (tr.data[0]) reset_ref_model();
        ADDR_LOCK:         ref_locked = (tr.data != UNLOCK_KEY);
        ADDR_SWITCH_CTRL:  if (!ref_locked) ref_switch_ctrl = tr.data & MASK_SWITCH_CTRL;
        ADDR_PORT_ENABLE:  if (!ref_locked) ref_port_en     = tr.data[3:0];
        ADDR_FWD_ENABLE:   if (!ref_locked) ref_fwd_en      = tr.data[3:0];
        ADDR_GEN_PKT_CFG:  if (!ref_locked) begin
          ref_gen_pkt_cfg = tr.data & MASK_GEN_PKT_CFG;
          if (tr.data[15:8] == 8'd0) ref_gen_pkt_cfg[15:8] = 8'd1;
        end
        ADDR_GEN_INTERVAL: if (!ref_locked) ref_gen_interval = tr.data[15:0];
        ADDR_GEN_COUNT:    if (!ref_locked) ref_gen_count    = tr.data[15:0];
        default: ;
      endcase
    end else begin
      case (tr.addr)
        ADDR_DEVICE_ID:    check_val("DEVICE_ID",    tr.data, RST_DEVICE_ID);
        ADDR_VERSION:      check_val("VERSION",      tr.data, RST_VERSION);
        ADDR_SWITCH_CTRL:  check_val("SWITCH_CTRL",  tr.data, ref_switch_ctrl);
        ADDR_PORT_ENABLE:  check_val("PORT_ENABLE",  tr.data, {28'h0, ref_port_en});
        ADDR_FWD_ENABLE:   check_val("FWD_ENABLE",   tr.data, {28'h0, ref_fwd_en});
        ADDR_GEN_PKT_CFG:  check_val("GEN_PKT_CFG",  tr.data, ref_gen_pkt_cfg);
        ADDR_GEN_INTERVAL: check_val("GEN_INTERVAL", tr.data, {16'h0, ref_gen_interval});
        ADDR_GEN_COUNT:    check_val("GEN_COUNT",    tr.data, {16'h0, ref_gen_count});
        ADDR_LOCK:         check_val("LOCK",         tr.data, {31'h0, ref_locked});
        ADDR_IRQ_FORCE,
        ADDR_ERR_INJECT,
        ADDR_SOFT_RESET:   check_val("WO_REG_ZERO",  tr.data, 32'h0);
        default: ;
      endcase
    end
  endfunction

  function void check_val(string reg_name, logic [31:0] act, logic [31:0] exp);
    if (act !== exp) begin
      `uvm_error("SCB_MISMATCH", $sformatf("%s read mismatch: Exp=0x%08h, Got=0x%08h",
                 reg_name, exp, act))
      error_count++;
    end else begin
      `uvm_info("SCB_MATCH", $sformatf("%s verified: 0x%08h", reg_name, act), UVM_HIGH)
    end
  endfunction

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("SCB_SUMMARY", $sformatf("Total APB Transactions=%0d, Scoreboard Errors=%0d",
              total_txns, error_count), UVM_LOW)
  endfunction
endclass

// =============================================================================
// 7. Functional Coverage Collector (`pkt_cov`)
// =============================================================================
class pkt_cov extends uvm_subscriber #(apb_seq_item);
  `uvm_component_utils(pkt_cov)

  apb_seq_item tr;

  covergroup cg_apb_bus;
    option.per_instance = 1;

    cp_addr: coverpoint tr.addr {
      bins device_id     = {ADDR_DEVICE_ID};
      bins version       = {ADDR_VERSION};
      bins switch_status = {ADDR_SWITCH_STATUS};
      bins port_status   = {ADDR_PORT_STATUS};
      bins gen_status    = {ADDR_GEN_STATUS};
      bins stat_rx       = {ADDR_STAT_RX};
      bins stat_tx       = {ADDR_STAT_TX};
      bins stat_drop     = {ADDR_STAT_DROP};
      bins switch_ctrl   = {ADDR_SWITCH_CTRL};
      bins port_enable   = {ADDR_PORT_ENABLE};
      bins fwd_enable    = {ADDR_FWD_ENABLE};
      bins gen_ctrl      = {ADDR_GEN_CTRL};
      bins gen_pkt_cfg   = {ADDR_GEN_PKT_CFG};
      bins gen_interval  = {ADDR_GEN_INTERVAL};
      bins gen_count     = {ADDR_GEN_COUNT};
      bins irq_status    = {ADDR_IRQ_STATUS};
      bins irq_enable    = {ADDR_IRQ_ENABLE};
      bins irq_force     = {ADDR_IRQ_FORCE};
      bins err_status    = {ADDR_ERR_STATUS};
      bins err_enable    = {ADDR_ERR_ENABLE};
      bins err_inject    = {ADDR_ERR_INJECT};
      bins err_count     = {ADDR_ERR_COUNT};
      bins err_info      = {ADDR_ERR_INFO};
      bins lock          = {ADDR_LOCK};
      bins soft_reset    = {ADDR_SOFT_RESET};
      bins unaligned     = {[16'h0001:16'h0060]} with (item[1:0] != 2'b00);
      bins out_of_range  = {[16'h0061:16'hFFFF]};
    }

    cp_write: coverpoint tr.write {
      bins read_op  = {1'b0};
      bins write_op = {1'b1};
    }

    cp_slverr: coverpoint tr.slverr {
      bins ok  = {1'b0};
      bins err = {1'b1};
    }

    cx_rw_addr: cross cp_write, cp_addr;
  endgroup

  covergroup cg_lock_ops;
    option.per_instance = 1;

    cp_lock_key: coverpoint tr.data iff (tr.write && tr.addr == ADDR_LOCK) {
      bins unlock_key = {UNLOCK_KEY};
      bins relock_val = default;
    }
  endgroup

  covergroup cg_pkt_cfg;
    option.per_instance = 1;

    cp_dst_port: coverpoint tr.data[1:0] iff (tr.write && tr.addr == ADDR_GEN_PKT_CFG && !tr.slverr) {
      bins dst[] = {[0:3]};
    }

    cp_src_port: coverpoint tr.data[3:2] iff (tr.write && tr.addr == ADDR_GEN_PKT_CFG && !tr.slverr) {
      bins src[] = {[0:3]};
    }

    cp_pkt_len: coverpoint tr.data[15:8] iff (tr.write && tr.addr == ADDR_GEN_PKT_CFG && !tr.slverr) {
      bins clamp_zero = {8'd0};
      bins min_len    = {8'd1};
      bins mid_len    = {[8'd2:8'd15]};
      bins max_len    = {[8'd16:8'd255]};
    }

    cp_port_en: coverpoint tr.data[3:0] iff (tr.write && tr.addr == ADDR_PORT_ENABLE && !tr.slverr) {
      bins all_enabled  = {4'hF};
      bins all_disabled = {4'h0};
      bins partial_mask = {[4'h1:4'hE]};
    }

    cp_fwd_en: coverpoint tr.data[3:0] iff (tr.write && tr.addr == ADDR_FWD_ENABLE && !tr.slverr) {
      bins all_enabled  = {4'hF};
      bins all_disabled = {4'h0};
      bins partial_mask = {[4'h1:4'hE]};
    }
  endgroup

  function new(string name = "pkt_cov", uvm_component parent = null);
    super.new(name, parent);
    cg_apb_bus  = new();
    cg_lock_ops = new();
    cg_pkt_cfg  = new();
  endfunction

  virtual function void write(apb_seq_item t);
    tr = t;
    cg_apb_bus.sample();
    cg_lock_ops.sample();
    cg_pkt_cfg.sample();
  endfunction

  virtual function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("COV_SUMMARY", $sformatf("Coverage Summary -> APB Bus: %0.2f%% | Lock: %0.2f%% | Config: %0.2f%%",
              cg_apb_bus.get_inst_coverage(),
              cg_lock_ops.get_inst_coverage(),
              cg_pkt_cfg.get_inst_coverage()), UVM_LOW)
  endfunction
endclass

// =============================================================================
// 8. UVM Environment (`pkt_env`)
// =============================================================================
class pkt_env extends uvm_env;
  `uvm_component_utils(pkt_env)

  apb_agent                         agnt;
  pkt_scb                           scb;
  pkt_cov                           cov;
  pkt_reg_block                     regmodel;
  apb_reg_adapter                   adapter;
  uvm_reg_predictor #(apb_seq_item) predictor;

  function new(string name = "pkt_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agnt      = apb_agent                        ::type_id::create("agnt", this);
    scb       = pkt_scb                          ::type_id::create("scb", this);
    cov       = pkt_cov                          ::type_id::create("cov", this);
    adapter   = apb_reg_adapter                  ::type_id::create("adapter");
    predictor = uvm_reg_predictor#(apb_seq_item) ::type_id::create("predictor", this);

    regmodel  = pkt_reg_block::type_id::create("regmodel");
    regmodel.build();
    regmodel.reset();
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    regmodel.apb_map.set_sequencer(agnt.sqr, adapter);
    regmodel.apb_map.set_auto_predict(0);

    predictor.map     = regmodel.apb_map;
    predictor.adapter = adapter;
    agnt.mon.item_collected_port.connect(predictor.bus_in);
    agnt.mon.item_collected_port.connect(scb.apb_imp);
    agnt.mon.item_collected_port.connect(cov.analysis_export);
  endfunction
endclass

// =============================================================================
// 9. Sequences
// =============================================================================

// Sequence A: Basic Write/Read Check
class pkt_write_read_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(pkt_write_read_seq)

  pkt_reg_block  rm;
  virtual apb_if vif;

  function new(string name = "pkt_write_read_seq");
    super.new(name);
  endfunction

  virtual task body();
    uvm_status_e   status;
    uvm_reg_data_t rdata;

    `uvm_info("WR_RD_SEQ", "=== Starting Custom Write & Read Test Sequence ===", UVM_LOW)

    // 1. Unlock CSR bank[cite: 1]
    `uvm_info("WR_RD_SEQ", "Unlocking CSR bank with key 0xA5A5C3C3...", UVM_LOW)
    rm.LOCK.write(status, UNLOCK_KEY);
    rm.LOCK.read(status, rdata);
    if (rdata !== 32'h0)
      `uvm_error("WR_RD_SEQ", $sformatf("Unlock failed! Expected LOCK=0, got 0x%08h", rdata))
    else
      `uvm_info("WR_RD_SEQ", "CSR bank successfully unlocked.", UVM_LOW)

    // 2. PORT_ENABLE (0x24)
    `uvm_info("WR_RD_SEQ", "Writing 0x0A to PORT_ENABLE (offset 0x24)...", UVM_LOW)
    rm.PORT_ENABLE.write(status, 32'h0000_000A);
    rm.PORT_ENABLE.read(status, rdata);
    `uvm_info("WR_RD_SEQ", $sformatf("PORT_ENABLE Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    // 3. FWD_ENABLE (0x28)
    `uvm_info("WR_RD_SEQ", "Writing 0x05 to FWD_ENABLE (offset 0x28)...", UVM_LOW)
    rm.FWD_ENABLE.write(status, 32'h0000_0005);
    rm.FWD_ENABLE.read(status, rdata);
    `uvm_info("WR_RD_SEQ", $sformatf("FWD_ENABLE Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    // 4. SWITCH_CTRL (0x20)
    `uvm_info("WR_RD_SEQ", "Writing 0x09 (ENABLE + IRQ_GLOBAL_EN) to SWITCH_CTRL (offset 0x20)...", UVM_LOW)
    rm.SWITCH_CTRL.write(status, 32'h0000_0009);
    rm.SWITCH_CTRL.read(status, rdata);
    `uvm_info("WR_RD_SEQ", $sformatf("SWITCH_CTRL Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    `uvm_info("WR_RD_SEQ", "=== Write & Read Test Sequence Completed Successfully ===", UVM_LOW)
  endtask
endclass

// Sequence B: Coverage Closure Sweep Sequence (Hits 100% on all bins)
class pkt_cov_rand_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(pkt_cov_rand_seq)

  pkt_reg_block  rm;
  virtual apb_if vif;

  function new(string name = "pkt_cov_rand_seq");
    super.new(name);
  endfunction

  task raw_apb(input bit [15:0] addr, input bit write, inout bit [31:0] data, output bit slverr);
    apb_seq_item item = apb_seq_item::type_id::create("item");
    start_item(item);
    item.addr  = addr;
    item.write = write;
    item.data  = data;
    finish_item(item);
    data   = item.data;
    slverr = item.slverr;
  endtask

  virtual task body();
    uvm_status_e   status;
    uvm_reg_data_t rdata;
    bit [31:0]     raw_data;
    bit            slverr;
    uvm_reg        all_regs[$];

    `uvm_info("COV_SEQ", "Starting Full Coverage Sweep...", UVM_LOW)

    // 1. Read & Write All 25 Registers while LOCKED (Touches all CSR read/write bins)
    rm.get_registers(all_regs);
    foreach (all_regs[i]) begin
      all_regs[i].read(status, rdata);
      all_regs[i].write(status, 32'hFFFF_FFFF);
    end

    // 2. Unlock CSR Bank
    rm.LOCK.write(status, UNLOCK_KEY);
    rm.LOCK.read(status, rdata);

    // 3. Sweep all cg_pkt_cfg bins (DST_PORT, SRC_PORT, LENGTH, PORT_EN, FWD_EN)
    for (int dst = 0; dst < 4; dst++) begin
      for (int src = 0; src < 4; src++) begin
        bit [7:0] test_lens[4] = '{8'd0, 8'd1, 8'd8, 8'd16};
        foreach (test_lens[l]) begin
          bit [31:0] cfg_val = {8'h00, test_lens[l], src[1:0], dst[1:0]};
          rm.GEN_PKT_CFG.write(status, cfg_val);
          rm.GEN_PKT_CFG.read(status, rdata);
        end
      end
    end

    // Hit PORT_ENABLE and FWD_ENABLE bins (0x0, 0xF, partial)
    rm.PORT_ENABLE.write(status, 32'h0);
    rm.PORT_ENABLE.write(status, 32'hF);
    rm.PORT_ENABLE.write(status, 32'hA);
    rm.FWD_ENABLE.write(status, 32'h0);
    rm.FWD_ENABLE.write(status, 32'hF);
    rm.FWD_ENABLE.write(status, 32'h5);

    // 4. Hit unaligned & out-of-range addresses to cover PSLVERR=1 bins
    raw_data = 32'hA5A5_0001;
    raw_apb(16'h0002, 1'b1, raw_data, slverr); // Unaligned write
    raw_apb(16'h0006, 1'b0, raw_data, slverr); // Unaligned read
    raw_apb(16'h0064, 1'b1, raw_data, slverr); // Out-of-range write (>0x60)
    raw_apb(16'h0080, 1'b0, raw_data, slverr); // Out-of-range read (>0x60)

    // 5. Relock with non-key write
    rm.LOCK.write(status, 32'hDEAD_BEEF);
    rm.LOCK.read(status, rdata);

    `uvm_info("COV_SEQ", "Coverage Closure Sweep Completed.", UVM_LOW)
  endtask
endclass

// =============================================================================
// 10. UVM Tests
// =============================================================================
class pkt_write_read_test extends uvm_test;
  `uvm_component_utils(pkt_write_read_test)

  pkt_env        env;
  virtual apb_if vif;

  function new(string name = "pkt_write_read_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = pkt_env::type_id::create("env", this);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("TST_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    pkt_write_read_seq seq = pkt_write_read_seq::type_id::create("seq");

    phase.raise_objection(this);
    @(posedge vif.presetn);
    repeat (5) @(posedge vif.pclk);

    seq.rm  = env.regmodel;
    seq.vif = vif;
    seq.start(env.agnt.sqr);

    repeat (10) @(posedge vif.pclk);
    phase.drop_objection(this);
  endtask
endclass

class pkt_cov_test extends uvm_test;
  `uvm_component_utils(pkt_cov_test)

  pkt_env        env;
  virtual apb_if vif;

  function new(string name = "pkt_cov_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = pkt_env::type_id::create("env", this);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("TST_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    pkt_cov_rand_seq seq = pkt_cov_rand_seq::type_id::create("seq");

    phase.raise_objection(this);
    @(posedge vif.presetn);
    repeat (5) @(posedge vif.pclk);

    seq.rm  = env.regmodel;
    seq.vif = vif;
    seq.start(env.agnt.sqr);

    repeat (10) @(posedge vif.pclk);
    phase.drop_objection(this);
  endtask
endclass

// =============================================================================
// 11. Top-Level Testbench (`tb`)
// =============================================================================
module tb;
  logic pclk;
  logic presetn;

  // 100 MHz Clock Generator (Period = 10ns)
  initial begin
    pclk = 1'b0;
    forever #5 pclk = ~pclk;
  end

  // Active-Low Reset Generator
  initial begin
    presetn = 1'b0;
    repeat (5) @(posedge pclk);
    presetn = 1'b1;
  end

  // APB Interface Instance
  apb_if vif(pclk, presetn);

  // DUT Instance (matches HDL root path 'tb.dut')[cite: 3]
  apb_pkt_switch dut (
    .pclk    (pclk),
    .presetn (presetn),
    .psel    (vif.psel),
    .penable (vif.penable),
    .pwrite  (vif.pwrite),
    .paddr   (vif.paddr),
    .pwdata  (vif.pwdata),
    .prdata  (vif.prdata),
    .pready  (vif.pready),
    .pslverr (vif.pslverr),
    .irq     (vif.irq)
  );

  // Global simulation timeout guardrail (50 us)
  initial begin
    #50000ns;
    $display("TB TIMEOUT: Simulation ran too long!");
    $finish;
  end

  initial begin
    uvm_config_db#(virtual apb_if)::set(null, "*", "vif", vif);
    run_test(); // Picks test dynamically from +UVM_TESTNAME
  end
endmodule
