class pkt_write_read_test extends uvm_test;
  `uvm_component_utils(pkt_write_read_test)

  pkt_env        env;
  virtual apb_if vif;

  function new(string name = "pkt_write_read_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = pkt_env::type_id::create("env", this);
    if (!uvm_config_db#(virtual apb_if)::get(this, "", "vif", vif))
      `uvm_fatal("TST_NOVIF", "Virtual interface not found in uvm_config_db")
  endfunction

  virtual task run_phase(uvm_phase phase);
    pkt_write_read_seq seq = pkt_write_read_seq::type_id::create("seq");

    phase.raise_objection(this);
    @(posedge vif.presetn);
    //repeat (5) 
@(posedge vif.pclk);

    seq.rm  = env.regmodel;
    seq.vif = vif;
    seq.start(env.agnt.sqr);

    //repeat (10) 
@(posedge vif.pclk);
#10;
    phase.drop_objection(this);
  endtask
endclass
