class pkt_full_verif_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(pkt_full_verif_seq)

  pkt_reg_block  rm;
  virtual apb_if vif;

  function new(string name = "pkt_full_verif_seq");
    super.new(name);
  endfunction

  // Helper task for raw APB bus transfers (to test unaligned/unmapped PSLVERR)
  task raw_apb(input bit [15:0] addr, input bit write,
               inout bit [31:0] data, output bit slverr);
    apb_seq_item item = apb_seq_item::type_id::create("item");
    start_item(item);
    item.addr  = addr;
    item.write = write;
    item.data  = data;
    finish_item(item);
    data   = item.data;
    slverr = item.slverr;
  endtask

  // Helper task to poll GEN_STATUS.DONE
  task wait_for_gen_done();
    uvm_status_e   status;
    uvm_reg_data_t val;
    do begin
      @(posedge vif.pclk);
      rm.GEN_STATUS.read(status, val);
    end while (val[1] == 1'b0);
  endtask

  virtual task body();
    uvm_status_e   status;
    uvm_reg_data_t rdata;
    bit [31:0]     raw_data;
    bit            slverr;

    // -------------------------------------------------------------------------
    // Phase 1: Power-On Reset Verification
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 1. Reading Reset Values via RAL ===", UVM_LOW)
    rm.DEVICE_ID    .read(status, rdata);
    rm.VERSION      .read(status, rdata);
    rm.SWITCH_STATUS.read(status, rdata);
    rm.PORT_ENABLE  .read(status, rdata);
    rm.FWD_ENABLE   .read(status, rdata);
    rm.GEN_PKT_CFG  .read(status, rdata);
    rm.GEN_INTERVAL .read(status, rdata);
    rm.GEN_COUNT    .read(status, rdata);
    rm.LOCK         .read(status, rdata);

    // -------------------------------------------------------------------------
    // Phase 2: Lock Protection Check (Write blocked while LOCKED=1)
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 2. Testing Write Protection While Locked ===", UVM_LOW)
    rm.PORT_ENABLE.write(status, 32'h0000_0003);
    rm.PORT_ENABLE.read(status, rdata);
    if (rdata !== 32'h0000_000F)
      `uvm_error("SEQ", "PORT_ENABLE modified while LOCKED=1!")

    // -------------------------------------------------------------------------
    // Phase 3: Unlock & Run Section 6.1 Programming Example (4 Packets)
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 3. Unlocking & Running 4-Packet Forwarded Traffic ===", UVM_LOW)
    rm.LOCK        .write(status, UNLOCK_KEY);
    rm.PORT_ENABLE .write(status, 32'h0000_000F);
    rm.FWD_ENABLE  .write(status, 32'h0000_000F);
    rm.SWITCH_CTRL .write(status, 32'h0000_0009); // ENABLE + IRQ_GLOBAL_EN
    rm.GEN_PKT_CFG .write(status, 32'h0010_0401); // Seed=0x10, Len=4, Src=0, Dst=1
    rm.GEN_INTERVAL.write(status, 32'h0000_0002); // Gap=2
    rm.GEN_COUNT   .write(status, 32'h0000_0004); // Count=4
    rm.IRQ_ENABLE  .write(status, 32'h0000_0041); // GEN_DONE + START_ACK
    rm.GEN_CTRL    .write(status, 32'h0000_0003); // ENABLE + START pulse

    wait_for_gen_done();

    rm.STAT_RX .read(status, rdata);
    if (rdata !== 32'd4) `uvm_error("SEQ", $sformatf("Expected STAT_RX=4, got %0d", rdata))

    rm.STAT_TX .read(status, rdata);
    if (rdata !== 32'd4) `uvm_error("SEQ", $sformatf("Expected STAT_TX=4, got %0d", rdata))

    rm.STAT_DROP.read(status, rdata);
    if (rdata !== 32'd0) `uvm_error("SEQ", $sformatf("Expected STAT_DROP=0, got %0d", rdata))

    // Verify W1C on IRQ_STATUS
    rm.IRQ_STATUS.write(status, 32'h0000_00FF);
    rm.IRQ_STATUS.read(status, rdata);
    if (rdata !== 32'd0) `uvm_error("SEQ", "IRQ_STATUS failed to clear on W1C")

    // -------------------------------------------------------------------------
    // Phase 4: Queue Almost-Full (>=8) & Queue Overflow (16 Beats)
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 4. Testing Queue Almost-Full & Queue Overflow ===", UVM_LOW)
    // Clear stats first via STAT_CLEAR pulse (bit 1)
    rm.SWITCH_CTRL .write(status, 32'h0000_000B); // IRQ_GLOBAL_EN(8) + STAT_CLEAR(2) + ENABLE(1)
    rm.GEN_PKT_CFG .write(status, 32'h00AA_1002); // Len=16 (0x10), Dst=2
    rm.GEN_INTERVAL.write(status, 32'h0000_0000); // 0 gap -> back-to-back
    rm.GEN_COUNT   .write(status, 32'h0000_0002); // 2 packets: Pkt 1 fills queue to 16, Pkt 2 overflows
    rm.GEN_CTRL    .write(status, 32'h0000_0003);

    wait_for_gen_done();

    rm.STAT_TX  .read(status, rdata);
    if (rdata !== 32'd1) `uvm_error("SEQ", $sformatf("Expected STAT_TX=1, got %0d", rdata))

    rm.STAT_DROP.read(status, rdata);
    if (rdata !== 32'd1) `uvm_error("SEQ", $sformatf("Expected STAT_DROP=1, got %0d", rdata))

    rm.ERR_STATUS.read(status, rdata);
    if (!rdata[2]) `uvm_error("SEQ", "Expected ERR_STATUS.QUEUE_OVERFLOW (bit 2) == 1")

    rm.ERR_STATUS.write(status, 32'h0000_00FF); // Clear errors
    rm.IRQ_STATUS.write(status, 32'h0000_00FF); // Clear IRQs

    // -------------------------------------------------------------------------
    // Phase 5: Disabled Port Drop & DEST_ERROR
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 5. Testing Disabled Destination Port Drop ===", UVM_LOW)
    rm.PORT_ENABLE.write(status, 32'h0000_0007); // Disable Port 3
    rm.GEN_PKT_CFG.write(status, 32'h00BB_0203); // Len=2, Dst=3
    rm.GEN_COUNT  .write(status, 32'h0000_0002); // 2 packets
    rm.GEN_CTRL   .write(status, 32'h0000_0003);

    wait_for_gen_done();

    rm.ERR_STATUS.read(status, rdata);
    if (!rdata[1]) `uvm_error("SEQ", "Expected ERR_STATUS.DEST_ERROR (bit 1) == 1")

    // -------------------------------------------------------------------------
    // Phase 6: Diagnostic Error Injection & Population Count
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 6. Testing Error Injection & ERR_COUNT/ERR_INFO ===", UVM_LOW)
    rm.ERR_INJECT.write(status, 32'h8000_0000); // Clear ERR_COUNT and ERR_INFO first
    rm.ERR_INJECT.write(status, 32'h0000_0028); // Inject CRC_ERROR (bit 5) + UNDERSIZE (bit 3) -> popcount=2

    rm.ERR_COUNT.read(status, rdata);
    if (rdata !== 32'd2) `uvm_error("SEQ", $sformatf("Expected ERR_COUNT=2, got %0d", rdata))

    rm.ERR_INFO.read(status, rdata);
    if (rdata[7:0] !== 8'd3 || rdata[15:8] !== 8'd1)
      `uvm_error("SEQ", $sformatf("ERR_INFO mismatch: 0x%08h", rdata))

    // -------------------------------------------------------------------------
    // Phase 7: Unaligned & Unmapped APB Transfers (PSLVERR) + SOFT_RESET
    // -------------------------------------------------------------------------
    `uvm_info("SEQ", "=== 7. Testing PSLVERR & SOFT_RESET ===", UVM_LOW)
    raw_data = 32'h1234_5678;
    raw_apb(16'h0002, 1'b1, raw_data, slverr); // Unaligned write
    raw_apb(16'h0064, 1'b0, raw_data, slverr); // Unmapped read

    // Trigger SOFT_RESET
    rm.SOFT_RESET.write(status, 32'h0000_0001);
    rm.reset();
    rm.LOCK.read(status, rdata);
    if (rdata !== 32'h1) `uvm_error("SEQ", "CSR bank did not relock after SOFT_RESET!")
  endtask
endclass

