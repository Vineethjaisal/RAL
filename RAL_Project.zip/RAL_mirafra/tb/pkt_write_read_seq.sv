class pkt_write_read_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(pkt_write_read_seq)

  pkt_reg_block rm;
  virtual apb_if  vif;

  function new(string name = "pkt_write_read_seq");
    super.new(name);
  endfunction

  virtual task body();
    uvm_status_e   status;
    uvm_reg_data_t rdata;

    `uvm_info("WR_RD_SEQ", "=== Starting Custom Write & Read Test Sequence ===", UVM_LOW)

    // 1. Unlock the CSR bank (Required because bank powers up locked)[cite: 1]
    `uvm_info("WR_RD_SEQ", "Unlocking CSR bank with key 0xA5A5C3C3...", UVM_LOW)
    rm.LOCK.write(status, UNLOCK_KEY);
    rm.LOCK.read(status, rdata);
    if (rdata !== 32'h0000_0000)
      `uvm_error("WR_RD_SEQ", $sformatf("Unlock failed! Expected LOCK=0, got 0x%08h", rdata))
    else
      `uvm_info("WR_RD_SEQ", "CSR bank successfully unlocked.", UVM_LOW)

    // 2. Write and Read-Back Test: PORT_ENABLE (Offset 0x24)
    `uvm_info("WR_RD_SEQ", "Writing 0x0A to PORT_ENABLE (offset 0x24)...", UVM_LOW)
    rm.PORT_ENABLE.write(status, 32'h0000_000A);
    
    rm.PORT_ENABLE.read(status, rdata);
    if (rdata !== 32'h0000_000A)
      `uvm_error("WR_RD_SEQ", $sformatf("PORT_ENABLE Mismatch: Exp=0x0000000A, Got=0x%08h", rdata))
    else
      `uvm_info("WR_RD_SEQ", $sformatf("PORT_ENABLE Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    // 3. Write and Read-Back Test: FWD_ENABLE (Offset 0x28)
    `uvm_info("WR_RD_SEQ", "Writing 0x05 to FWD_ENABLE (offset 0x28)...", UVM_LOW)
    rm.FWD_ENABLE.write(status, 32'h0000_0005);
    
    rm.FWD_ENABLE.read(status, rdata);
    if (rdata !== 32'h0000_0005)
      `uvm_error("WR_RD_SEQ", $sformatf("FWD_ENABLE Mismatch: Exp=0x00000005, Got=0x%08h", rdata))
    else
      `uvm_info("WR_RD_SEQ", $sformatf("FWD_ENABLE Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    // 4. Write and Read-Back Test: SWITCH_CTRL (Offset 0x20)
    `uvm_info("WR_RD_SEQ", "Writing 0x09 (ENABLE + IRQ_GLOBAL_EN) to SWITCH_CTRL (offset 0x20)...", UVM_LOW)
    rm.SWITCH_CTRL.write(status, 32'h0000_0009);
    
    rm.SWITCH_CTRL.read(status, rdata);
    if (rdata !== 32'h0000_0009)
      `uvm_error("WR_RD_SEQ", $sformatf("SWITCH_CTRL Mismatch: Exp=0x00000009, Got=0x%08h", rdata))
    else
      `uvm_info("WR_RD_SEQ", $sformatf("SWITCH_CTRL Read-Back Verified: 0x%08h", rdata), UVM_LOW)

    `uvm_info("WR_RD_SEQ", "=== Write & Read Test Sequence Completed Successfully ===", UVM_LOW)
  endtask
endclass
