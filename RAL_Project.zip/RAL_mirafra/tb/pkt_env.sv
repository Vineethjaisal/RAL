class pkt_env extends uvm_env;
  `uvm_component_utils(pkt_env)

  apb_agent                         agnt;
  pkt_scb                           scb;
  pkt_reg_block                     regmodel;
  apb_reg_adapter                   adapter;
  uvm_reg_predictor #(apb_seq_item) predictor;

  function new(string name = "pkt_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agnt      = apb_agent                        ::type_id::create("agnt", this);
    scb       = pkt_scb                          ::type_id::create("scb", this);
    adapter   = apb_reg_adapter                  ::type_id::create("adapter");
    predictor = uvm_reg_predictor#(apb_seq_item) ::type_id::create("predictor", this);

    regmodel  = pkt_reg_block::type_id::create("regmodel");
    regmodel.build();
    regmodel.reset();
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    // Connect RAL map to sequencer & adapter
    regmodel.apb_map.set_sequencer(agnt.sqr, adapter);
    regmodel.apb_map.set_auto_predict(0);

    // Connect Monitor to Predictor and Scoreboard
    predictor.map     = regmodel.apb_map;
    predictor.adapter = adapter;
    agnt.mon.item_collected_port.connect(predictor.bus_in);
    agnt.mon.item_collected_port.connect(scb.apb_imp);
  endfunction
endclass
