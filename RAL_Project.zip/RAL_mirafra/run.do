
vlog -sv +acc +cover=bcefsx \
    rtl/apb_pkt_pkg.sv \
    rtl/pkt_generator.sv \
    rtl/pkt_switch.sv \
    rtl/apb_pkt_switch.sv

vlog -sv +acc +cover=bcefsx \
    +incdir+./rtl \
    +incdir+./ral \
    +incdir+./tb \
    ral/pkt_ral_pkg.sv \
    tb/tb_apb_pkt_switch.sv

vsim -voptargs="+acc" -coverage work.tb +UVM_TESTNAME=pkt_write_read_test +UVM_VERBOSITY=UVM_LOW -sv_seed random

    add wave -noupdate -divider "APB3 Bus Interface"
    add wave -noupdate -radix hexadecimal /tb/dut/pclk
    add wave -noupdate -radix hexadecimal /tb/dut/presetn
    add wave -noupdate -radix hexadecimal /tb/dut/psel
    add wave -noupdate -radix hexadecimal /tb/dut/penable
    add wave -noupdate -radix hexadecimal /tb/dut/pwrite
    add wave -noupdate -radix hexadecimal /tb/dut/paddr
    add wave -noupdate -radix hexadecimal /tb/dut/pwdata
    add wave -noupdate -radix hexadecimal /tb/dut/prdata
    add wave -noupdate -radix hexadecimal /tb/dut/pready
    add wave -noupdate -radix hexadecimal /tb/dut/pslverr
    add wave -noupdate -radix hexadecimal /tb/dut/irq

    add wave -noupdate -divider "CSR State & Security Lock"
    add wave -noupdate -radix hexadecimal /tb/dut/locked
    add wave -noupdate -radix hexadecimal /tb/dut/switch_ctrl_q
    add wave -noupdate -radix hexadecimal /tb/dut/port_enable_q
    add wave -noupdate -radix hexadecimal /tb/dut/fwd_enable_q
    add wave -noupdate -radix hexadecimal /tb/dut/irq_status_q
    add wave -noupdate -radix hexadecimal /tb/dut/irq_enable_q
    add wave -noupdate -radix hexadecimal /tb/dut/err_status_q
    add wave -noupdate -radix unsigned    /tb/dut/err_count_q
    add wave -noupdate -radix hexadecimal /tb/dut/err_info_q

    add wave -noupdate -divider "Packet Generator (u_gen)"
    add wave -noupdate -radix unsigned    /tb/dut/u_gen/fsm
    add wave -noupdate -radix hexadecimal /tb/dut/u_gen/running
    add wave -noupdate -radix unsigned    /tb/dut/u_gen/remaining
    add wave -noupdate -radix hexadecimal /tb/dut/u_gen/out_valid
    add wave -noupdate -radix hexadecimal /tb/dut/u_gen/out_sop
    add wave -noupdate -radix hexadecimal /tb/dut/u_gen/out_eop
    add wave -noupdate -radix unsigned    /tb/dut/u_gen/out_dst
    add wave -noupdate -radix unsigned    /tb/dut/u_gen/out_len
    add wave -noupdate -radix hexadecimal /tb/dut/u_gen/out_data

    add wave -noupdate -divider "4-Port Switch & Queues (u_sw)"
    add wave -noupdate -radix unsigned    /tb/dut/u_sw/q_level
    add wave -noupdate -radix unsigned    /tb/dut/u_sw/stat_rx
    add wave -noupdate -radix unsigned    /tb/dut/u_sw/stat_tx
    add wave -noupdate -radix unsigned    /tb/dut/u_sw/stat_drop
    add wave -noupdate -radix hexadecimal /tb/dut/u_sw/ovf_evt
    add wave -noupdate -radix hexadecimal /tb/dut/u_sw/dest_err_evt
    add wave -noupdate -radix hexadecimal /tb/dut/u_sw/drop_evt
    add wave -noupdate -radix hexadecimal /tb/dut/u_sw/fwd_eop_evt

    configure wave -namecolwidth 260
    configure wave -valuecolwidth 100

log -r /*
run -all


