// -----------------------------------------------------------------------------
// ral/pkt_ral_pkg.sv
// Sequence Item, APB Register Adapter, and 25-Register UVM RAL Model
// -----------------------------------------------------------------------------
package pkt_ral_pkg;
  import uvm_pkg::*;
  import apb_pkt_pkg::*;
  `include "uvm_macros.svh"

  // ===========================================================================
  // 1. APB Sequence Item
  // ===========================================================================
  class apb_seq_item extends uvm_sequence_item;
    rand logic [ADDR_W-1:0] addr;
    rand logic [DATA_W-1:0] data;
    rand logic              write;
    logic                   slverr;
    logic                   irq;

    `uvm_object_utils_begin(apb_seq_item)
      `uvm_field_int(addr,   UVM_ALL_ON)
      `uvm_field_int(data,   UVM_ALL_ON)
      `uvm_field_int(write,  UVM_ALL_ON)
      `uvm_field_int(slverr, UVM_ALL_ON)
      `uvm_field_int(irq,    UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "apb_seq_item");
      super.new(name);
    endfunction
  endclass

  // ===========================================================================
  // 2. APB Register Adapter
  // ===========================================================================
  class apb_reg_adapter extends uvm_reg_adapter;
    `uvm_object_utils(apb_reg_adapter)

    function new(string name = "apb_reg_adapter");
      super.new(name);
      supports_byte_enable = 0;
      provides_responses   = 0;//provides_responses=1
    endfunction

    virtual function uvm_sequence_item reg2bus(const ref uvm_reg_bus_op rw);
      apb_seq_item item = apb_seq_item::type_id::create("item");
      item.addr  = rw.addr[ADDR_W-1:0];
      item.data  = rw.data[DATA_W-1:0];
      item.write = (rw.kind == UVM_WRITE);
      return item;
    endfunction

    virtual function void bus2reg(uvm_sequence_item bus_item, ref uvm_reg_bus_op rw);
      apb_seq_item item;
      if (!$cast(item, bus_item)) begin
        `uvm_fatal("ADAPTER", "Provided bus_item is not of type apb_seq_item")
      end
      rw.kind   = item.write ? UVM_WRITE : UVM_READ;
      rw.addr   = item.addr;
      rw.data   = item.data;
      rw.status = item.slverr ? UVM_NOT_OK : UVM_IS_OK;
    endfunction
  endclass

  // ===========================================================================
  // 3. Individual CSR Classes (25 Registers: 0x00 to 0x60)
  // ===========================================================================

  // 0x00: DEVICE_ID (RO)
  class reg_device_id extends uvm_reg;
    `uvm_object_utils(reg_device_id)
    rand uvm_reg_field PRODUCT_ID, VENDOR_ID, REVISION;
    function new(string name = "reg_device_id"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      PRODUCT_ID = uvm_reg_field::type_id::create("PRODUCT_ID");
      VENDOR_ID  = uvm_reg_field::type_id::create("VENDOR_ID");
      REVISION   = uvm_reg_field::type_id::create("REVISION");
      PRODUCT_ID.configure(this, 16, 0,  "RO", 0, 16'h5357, 1, 0, 1);
      VENDOR_ID .configure(this, 8,  16, "RO", 0, 8'hA5,    1, 0, 1);
      REVISION  .configure(this, 8,  24, "RO", 0, 8'h02,    1, 0, 1);
    endfunction
  endclass

  // 0x04: VERSION (RO)
  class reg_version extends uvm_reg;
    `uvm_object_utils(reg_version)
    rand uvm_reg_field PATCH, MINOR, MAJOR;
    function new(string name = "reg_version"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      PATCH = uvm_reg_field::type_id::create("PATCH");
      MINOR = uvm_reg_field::type_id::create("MINOR");
      MAJOR = uvm_reg_field::type_id::create("MAJOR");
      PATCH.configure(this, 8, 0,  "RO", 0, 8'h00, 1, 0, 1);
      MINOR.configure(this, 8, 8,  "RO", 0, 8'h02, 1, 0, 1);
      MAJOR.configure(this, 8, 16, "RO", 0, 8'h01, 1, 0, 1);
    endfunction
  endclass

  // 0x08: SWITCH_STATUS (RO, Volatile)
  class reg_switch_status extends uvm_reg;
    `uvm_object_utils(reg_switch_status)
    rand uvm_reg_field IDLE, BUSY, SWITCH_EN, LOCKED, PORT_EN, GEN_RUNNING, ERR_ACTIVE, GEN_FSM;
    function new(string name = "reg_switch_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      IDLE        = uvm_reg_field::type_id::create("IDLE");
      BUSY        = uvm_reg_field::type_id::create("BUSY");
      SWITCH_EN   = uvm_reg_field::type_id::create("SWITCH_EN");
      LOCKED      = uvm_reg_field::type_id::create("LOCKED");
      PORT_EN     = uvm_reg_field::type_id::create("PORT_EN");
      GEN_RUNNING = uvm_reg_field::type_id::create("GEN_RUNNING");
      ERR_ACTIVE  = uvm_reg_field::type_id::create("ERR_ACTIVE");
      GEN_FSM     = uvm_reg_field::type_id::create("GEN_FSM");
      IDLE       .configure(this, 1, 0,  "RO", 1, 1'b1,  1, 0, 0);
      BUSY       .configure(this, 1, 1,  "RO", 1, 1'b0,  1, 0, 0);
      SWITCH_EN  .configure(this, 1, 2,  "RO", 1, 1'b0,  1, 0, 0);
      LOCKED     .configure(this, 1, 3,  "RO", 1, 1'b1,  1, 0, 0);
      PORT_EN    .configure(this, 4, 4,  "RO", 1, 4'hF,  1, 0, 0);
      GEN_RUNNING.configure(this, 1, 8,  "RO", 1, 1'b0,  1, 0, 0);
      ERR_ACTIVE .configure(this, 1, 9,  "RO", 1, 1'b0,  1, 0, 0);
      GEN_FSM    .configure(this, 2, 16, "RO", 1, 2'b00, 1, 0, 0);
    endfunction
  endclass

  // 0x0C: PORT_STATUS (RO, Volatile)
  class reg_port_status extends uvm_reg;
    `uvm_object_utils(reg_port_status)
    rand uvm_reg_field Q0_LEVEL, Q1_LEVEL, Q2_LEVEL, Q3_LEVEL;
    function new(string name = "reg_port_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      Q0_LEVEL = uvm_reg_field::type_id::create("Q0_LEVEL");
      Q1_LEVEL = uvm_reg_field::type_id::create("Q1_LEVEL");
      Q2_LEVEL = uvm_reg_field::type_id::create("Q2_LEVEL");
      Q3_LEVEL = uvm_reg_field::type_id::create("Q3_LEVEL");
      Q0_LEVEL.configure(this, 8, 0,  "RO", 1, 8'h0, 1, 0, 1);
      Q1_LEVEL.configure(this, 8, 8,  "RO", 1, 8'h0, 1, 0, 1);
      Q2_LEVEL.configure(this, 8, 16, "RO", 1, 8'h0, 1, 0, 1);
      Q3_LEVEL.configure(this, 8, 24, "RO", 1, 8'h0, 1, 0, 1);
    endfunction
  endclass

  // 0x10: GEN_STATUS (RO, Volatile)
  class reg_gen_status extends uvm_reg;
    `uvm_object_utils(reg_gen_status)
    rand uvm_reg_field RUNNING, DONE, FSM, REMAINING;
    function new(string name = "reg_gen_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      RUNNING   = uvm_reg_field::type_id::create("RUNNING");
      DONE      = uvm_reg_field::type_id::create("DONE");
      FSM       = uvm_reg_field::type_id::create("FSM");
      REMAINING = uvm_reg_field::type_id::create("REMAINING");
      RUNNING  .configure(this, 1,  0, "RO", 1, 1'b0,  1, 0, 0);
      DONE     .configure(this, 1,  1, "RO", 1, 1'b0,  1, 0, 0);
      FSM      .configure(this, 2,  2, "RO", 1, 2'b00, 1, 0, 0);
      REMAINING.configure(this, 16, 8, "RO", 1, 16'h0, 1, 0, 1);
    endfunction
  endclass

  // 0x14, 0x18, 0x1C: STAT_RX / STAT_TX / STAT_DROP (RO, Volatile)
  class reg_stat_cnt extends uvm_reg;
    `uvm_object_utils(reg_stat_cnt)
    rand uvm_reg_field COUNT;
    function new(string name = "reg_stat_cnt"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      COUNT = uvm_reg_field::type_id::create("COUNT");
      COUNT.configure(this, 16, 0, "RO", 1, 16'h0, 1, 0, 1);
    endfunction
  endclass

  // 0x20: SWITCH_CTRL (RW/WO)
  class reg_switch_ctrl extends uvm_reg;
    `uvm_object_utils(reg_switch_ctrl)
    rand uvm_reg_field ENABLE, STAT_CLEAR, IRQ_GLOBAL_EN;
    function new(string name = "reg_switch_ctrl"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      ENABLE        = uvm_reg_field::type_id::create("ENABLE");
      STAT_CLEAR    = uvm_reg_field::type_id::create("STAT_CLEAR");
      IRQ_GLOBAL_EN = uvm_reg_field::type_id::create("IRQ_GLOBAL_EN");
      ENABLE       .configure(this, 1, 0, "RW", 0, 1'b0, 1, 1, 0);
      STAT_CLEAR   .configure(this, 1, 1, "WO", 0, 1'b0, 1, 1, 0);
      IRQ_GLOBAL_EN.configure(this, 1, 3, "RW", 0, 1'b0, 1, 1, 0);
    endfunction
  endclass

  // 0x24, 0x28: PORT_ENABLE / FWD_ENABLE (RW)
  class reg_port_mask extends uvm_reg;
    `uvm_object_utils(reg_port_mask)
    rand uvm_reg_field MASK;
    function new(string name = "reg_port_mask"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      MASK = uvm_reg_field::type_id::create("MASK");
      MASK.configure(this, 4, 0, "RW", 0, 4'hF, 1, 1, 1);
    endfunction
  endclass

  // 0x2C: GEN_CTRL (RW/WO)
  class reg_gen_ctrl extends uvm_reg;
    `uvm_object_utils(reg_gen_ctrl)
    rand uvm_reg_field ENABLE, START, STOP, CONTINUOUS;
    function new(string name = "reg_gen_ctrl"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      ENABLE     = uvm_reg_field::type_id::create("ENABLE");
      START      = uvm_reg_field::type_id::create("START");
      STOP       = uvm_reg_field::type_id::create("STOP");
      CONTINUOUS = uvm_reg_field::type_id::create("CONTINUOUS");
      ENABLE    .configure(this, 1, 0, "RW", 0, 1'b0, 1, 1, 0);
      START     .configure(this, 1, 1, "WO", 0, 1'b0, 1, 1, 0);
      STOP      .configure(this, 1, 2, "WO", 0, 1'b0, 1, 1, 0);
      CONTINUOUS.configure(this, 1, 3, "RW", 0, 1'b0, 1, 1, 0);
    endfunction
  endclass

  // 0x30: GEN_PKT_CFG (RW)
  class reg_gen_pkt_cfg extends uvm_reg;
    `uvm_object_utils(reg_gen_pkt_cfg)
    rand uvm_reg_field DST_PORT, SRC_PORT, LENGTH, SEED;
    function new(string name = "reg_gen_pkt_cfg"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      DST_PORT = uvm_reg_field::type_id::create("DST_PORT");
      SRC_PORT = uvm_reg_field::type_id::create("SRC_PORT");
      LENGTH   = uvm_reg_field::type_id::create("LENGTH");
      SEED     = uvm_reg_field::type_id::create("SEED");
      DST_PORT.configure(this, 2, 0,  "RW", 0, 2'd1,  1, 1, 0);
      SRC_PORT.configure(this, 2, 2,  "RW", 0, 2'd0,  1, 1, 0);
      LENGTH  .configure(this, 8, 8,  "RW", 0, 8'h04, 1, 1, 1);
      SEED    .configure(this, 8, 16, "RW", 0, 8'h00, 1, 1, 1);
    endfunction
  endclass

  // 0x34: GEN_INTERVAL (RW)
  class reg_gen_interval extends uvm_reg;
    `uvm_object_utils(reg_gen_interval)
    rand uvm_reg_field INTERVAL;
    function new(string name = "reg_gen_interval"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      INTERVAL = uvm_reg_field::type_id::create("INTERVAL");
      INTERVAL.configure(this, 16, 0, "RW", 0, 16'h0002, 1, 1, 1);
    endfunction
  endclass

  // 0x38: GEN_COUNT (RW)
  class reg_gen_count extends uvm_reg;
    `uvm_object_utils(reg_gen_count)
    rand uvm_reg_field PACKET_COUNT;
    function new(string name = "reg_gen_count"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      PACKET_COUNT = uvm_reg_field::type_id::create("PACKET_COUNT");
      PACKET_COUNT.configure(this, 16, 0, "RW", 0, 16'h0004, 1, 1, 1);
    endfunction
  endclass

  // 0x3C: IRQ_STATUS (W1C)
  class reg_irq_status extends uvm_reg;
    `uvm_object_utils(reg_irq_status)
    rand uvm_reg_field GEN_DONE, ERROR, QUEUE_OVF, PACKET_DROPPED, PACKET_FWD, QUEUE_ALMOST_FULL, START_ACK, SW_EVENT;
    function new(string name = "reg_irq_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      GEN_DONE          = uvm_reg_field::type_id::create("GEN_DONE");
      ERROR             = uvm_reg_field::type_id::create("ERROR");
      QUEUE_OVF         = uvm_reg_field::type_id::create("QUEUE_OVF");
      PACKET_DROPPED    = uvm_reg_field::type_id::create("PACKET_DROPPED");
      PACKET_FWD        = uvm_reg_field::type_id::create("PACKET_FWD");
      QUEUE_ALMOST_FULL = uvm_reg_field::type_id::create("QUEUE_ALMOST_FULL");
      START_ACK         = uvm_reg_field::type_id::create("START_ACK");
      SW_EVENT          = uvm_reg_field::type_id::create("SW_EVENT");
      GEN_DONE         .configure(this, 1, 0, "W1C", 1, 1'b0, 1, 1, 0);
      ERROR            .configure(this, 1, 1, "W1C", 1, 1'b0, 1, 1, 0);
      QUEUE_OVF        .configure(this, 1, 2, "W1C", 1, 1'b0, 1, 1, 0);
      PACKET_DROPPED   .configure(this, 1, 3, "W1C", 1, 1'b0, 1, 1, 0);
      PACKET_FWD       .configure(this, 1, 4, "W1C", 1, 1'b0, 1, 1, 0);
      QUEUE_ALMOST_FULL.configure(this, 1, 5, "W1C", 1, 1'b0, 1, 1, 0);
      START_ACK        .configure(this, 1, 6, "W1C", 1, 1'b0, 1, 1, 0);
      SW_EVENT         .configure(this, 1, 7, "W1C", 1, 1'b0, 1, 1, 0);
    endfunction
  endclass

  // 0x40, 0x4C: IRQ_ENABLE / ERR_ENABLE (RW)
  class reg_byte_enable extends uvm_reg;
    `uvm_object_utils(reg_byte_enable)
    rand uvm_reg_field MASK;
    function new(string name = "reg_byte_enable"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      MASK = uvm_reg_field::type_id::create("MASK");
      MASK.configure(this, 8, 0, "RW", 0, 8'h00, 1, 1, 1);
    endfunction
  endclass

  // 0x44: IRQ_FORCE (WO)
  class reg_irq_force extends uvm_reg;
    `uvm_object_utils(reg_irq_force)
    rand uvm_reg_field FORCE;
    function new(string name = "reg_irq_force"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      FORCE = uvm_reg_field::type_id::create("FORCE");
      FORCE.configure(this, 8, 0, "WO", 0, 8'h00, 1, 1, 1);
    endfunction
  endclass

  // 0x48: ERR_STATUS (W1C)
  class reg_err_status extends uvm_reg;
    `uvm_object_utils(reg_err_status)
    rand uvm_reg_field BUS_ERROR, DEST_ERROR, QUEUE_OVERFLOW, UNDERSIZE, PROTOCOL_ERROR, CRC_ERROR, LENGTH_ERROR, INJECTED;
    function new(string name = "reg_err_status"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      BUS_ERROR      = uvm_reg_field::type_id::create("BUS_ERROR");
      DEST_ERROR     = uvm_reg_field::type_id::create("DEST_ERROR");
      QUEUE_OVERFLOW = uvm_reg_field::type_id::create("QUEUE_OVERFLOW");
      UNDERSIZE      = uvm_reg_field::type_id::create("UNDERSIZE");
      PROTOCOL_ERROR = uvm_reg_field::type_id::create("PROTOCOL_ERROR");
      CRC_ERROR      = uvm_reg_field::type_id::create("CRC_ERROR");
      LENGTH_ERROR   = uvm_reg_field::type_id::create("LENGTH_ERROR");
      INJECTED       = uvm_reg_field::type_id::create("INJECTED");
      BUS_ERROR     .configure(this, 1, 0, "W1C", 1, 1'b0, 1, 1, 0);
      DEST_ERROR    .configure(this, 1, 1, "W1C", 1, 1'b0, 1, 1, 0);
      QUEUE_OVERFLOW.configure(this, 1, 2, "W1C", 1, 1'b0, 1, 1, 0);
      UNDERSIZE     .configure(this, 1, 3, "W1C", 1, 1'b0, 1, 1, 0);
      PROTOCOL_ERROR.configure(this, 1, 4, "W1C", 1, 1'b0, 1, 1, 0);
      CRC_ERROR     .configure(this, 1, 5, "W1C", 1, 1'b0, 1, 1, 0);
      LENGTH_ERROR  .configure(this, 1, 6, "W1C", 1, 1'b0, 1, 1, 0);
      INJECTED      .configure(this, 1, 7, "W1C", 1, 1'b0, 1, 1, 0);
    endfunction
  endclass

  // 0x50: ERR_INJECT (WO)
  class reg_err_inject extends uvm_reg;
    `uvm_object_utils(reg_err_inject)
    rand uvm_reg_field INJECT_MASK, CLEAR_COUNT;
    function new(string name = "reg_err_inject"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      INJECT_MASK = uvm_reg_field::type_id::create("INJECT_MASK");
      CLEAR_COUNT = uvm_reg_field::type_id::create("CLEAR_COUNT");
      INJECT_MASK.configure(this, 8, 0,  "WO", 0, 8'h00, 1, 1, 0);
      CLEAR_COUNT.configure(this, 1, 31, "WO", 0, 1'b0,  1, 1, 0);
    endfunction
  endclass

  // 0x58: ERR_INFO (RO, Volatile)
  class reg_err_info extends uvm_reg;
    `uvm_object_utils(reg_err_info)
    rand uvm_reg_field LAST_CODE, SOURCE, DST_PORT, TX_SNAPSHOT;
    function new(string name = "reg_err_info"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      LAST_CODE   = uvm_reg_field::type_id::create("LAST_CODE");
      SOURCE      = uvm_reg_field::type_id::create("SOURCE");
      DST_PORT    = uvm_reg_field::type_id::create("DST_PORT");
      TX_SNAPSHOT = uvm_reg_field::type_id::create("TX_SNAPSHOT");
      LAST_CODE  .configure(this, 8,  0,  "RO", 1, 8'h00,  1, 0, 0);
      SOURCE     .configure(this, 8,  8,  "RO", 1, 8'h00,  1, 0, 0);
      DST_PORT   .configure(this, 2,  16, "RO", 1, 2'b00,  1, 0, 0);
      TX_SNAPSHOT.configure(this, 12, 20, "RO", 1, 12'h000,1, 0, 0);
    endfunction
  endclass

  // 0x5C: LOCK (RW Key / RO Lock Bit)
  class reg_lock extends uvm_reg;
    `uvm_object_utils(reg_lock)
    rand uvm_reg_field LOCKED, KEY;
    function new(string name = "reg_lock"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      LOCKED = uvm_reg_field::type_id::create("LOCKED");
      KEY    = uvm_reg_field::type_id::create("KEY");
      LOCKED.configure(this, 1,  0, "RO", 1, 1'b1,  1, 0, 0);
      KEY   .configure(this, 31, 1, "WO", 0, 31'h0, 1, 1, 0);
    endfunction
  endclass

  // 0x60: SOFT_RESET (WO)
  class reg_soft_reset extends uvm_reg;
    `uvm_object_utils(reg_soft_reset)
    rand uvm_reg_field PULSE;
    function new(string name = "reg_soft_reset"); super.new(name, 32, UVM_NO_COVERAGE); endfunction
    virtual function void build();
      PULSE = uvm_reg_field::type_id::create("PULSE");
      PULSE.configure(this, 1, 0, "WO", 0, 1'b0, 1, 1, 0);
    endfunction
  endclass

  // ===========================================================================
  // 4. Top-Level Register Block (`pkt_reg_block`)
  // ===========================================================================
  class pkt_reg_block extends uvm_reg_block;
    `uvm_object_utils(pkt_reg_block)

    rand reg_device_id     DEVICE_ID;
    rand reg_version       VERSION;
    rand reg_switch_status SWITCH_STATUS;
    rand reg_port_status   PORT_STATUS;
    rand reg_gen_status    GEN_STATUS;
    rand reg_stat_cnt      STAT_RX;
    rand reg_stat_cnt      STAT_TX;
    rand reg_stat_cnt      STAT_DROP;
    rand reg_switch_ctrl   SWITCH_CTRL;
    rand reg_port_mask     PORT_ENABLE;
    rand reg_port_mask     FWD_ENABLE;
    rand reg_gen_ctrl      GEN_CTRL;
    rand reg_gen_pkt_cfg   GEN_PKT_CFG;
    rand reg_gen_interval  GEN_INTERVAL;
    rand reg_gen_count     GEN_COUNT;
    rand reg_irq_status    IRQ_STATUS;
    rand reg_byte_enable   IRQ_ENABLE;
    rand reg_irq_force     IRQ_FORCE;
    rand reg_err_status    ERR_STATUS;
    rand reg_byte_enable   ERR_ENABLE;
    rand reg_err_inject    ERR_INJECT;
    rand reg_stat_cnt      ERR_COUNT;
    rand reg_err_info      ERR_INFO;
    rand reg_lock          LOCK;
    rand reg_soft_reset    SOFT_RESET;

    uvm_reg_map apb_map;

    function new(string name = "pkt_reg_block");
      super.new(name, UVM_NO_COVERAGE);
    endfunction

    virtual function void build();
      add_hdl_path("tb.dut", "RTL");

      DEVICE_ID     = reg_device_id    ::type_id::create("DEVICE_ID");
      VERSION       = reg_version      ::type_id::create("VERSION");
      SWITCH_STATUS = reg_switch_status::type_id::create("SWITCH_STATUS");
      PORT_STATUS   = reg_port_status  ::type_id::create("PORT_STATUS");
      GEN_STATUS    = reg_gen_status   ::type_id::create("GEN_STATUS");
      STAT_RX       = reg_stat_cnt     ::type_id::create("STAT_RX");
      STAT_TX       = reg_stat_cnt     ::type_id::create("STAT_TX");
      STAT_DROP     = reg_stat_cnt     ::type_id::create("STAT_DROP");
      SWITCH_CTRL   = reg_switch_ctrl  ::type_id::create("SWITCH_CTRL");
      PORT_ENABLE   = reg_port_mask    ::type_id::create("PORT_ENABLE");
      FWD_ENABLE    = reg_port_mask    ::type_id::create("FWD_ENABLE");
      GEN_CTRL      = reg_gen_ctrl     ::type_id::create("GEN_CTRL");
      GEN_PKT_CFG   = reg_gen_pkt_cfg  ::type_id::create("GEN_PKT_CFG");
      GEN_INTERVAL  = reg_gen_interval ::type_id::create("GEN_INTERVAL");
      GEN_COUNT     = reg_gen_count    ::type_id::create("GEN_COUNT");
      IRQ_STATUS    = reg_irq_status   ::type_id::create("IRQ_STATUS");
      IRQ_ENABLE    = reg_byte_enable  ::type_id::create("IRQ_ENABLE");
      IRQ_FORCE     = reg_irq_force    ::type_id::create("IRQ_FORCE");
      ERR_STATUS    = reg_err_status   ::type_id::create("ERR_STATUS");
      ERR_ENABLE    = reg_byte_enable  ::type_id::create("ERR_ENABLE");
      ERR_INJECT    = reg_err_inject   ::type_id::create("ERR_INJECT");
      ERR_COUNT     = reg_stat_cnt     ::type_id::create("ERR_COUNT");
      ERR_INFO      = reg_err_info     ::type_id::create("ERR_INFO");
      LOCK          = reg_lock         ::type_id::create("LOCK");
      SOFT_RESET    = reg_soft_reset   ::type_id::create("SOFT_RESET");

      DEVICE_ID    .configure(this); DEVICE_ID    .build();
      VERSION      .configure(this); VERSION      .build();
      SWITCH_STATUS.configure(this); SWITCH_STATUS.build();
      PORT_STATUS  .configure(this); PORT_STATUS  .build();
      GEN_STATUS   .configure(this); GEN_STATUS   .build();
      STAT_RX      .configure(this); STAT_RX      .build();
      STAT_TX      .configure(this); STAT_TX      .build();
      STAT_DROP    .configure(this); STAT_DROP    .build();
      SWITCH_CTRL  .configure(this); SWITCH_CTRL  .build();
      PORT_ENABLE  .configure(this); PORT_ENABLE  .build();
      FWD_ENABLE   .configure(this); FWD_ENABLE   .build();
      GEN_CTRL     .configure(this); GEN_CTRL     .build();
      GEN_PKT_CFG  .configure(this); GEN_PKT_CFG  .build();
      GEN_INTERVAL .configure(this); GEN_INTERVAL .build();
      GEN_COUNT    .configure(this); GEN_COUNT    .build();
      IRQ_STATUS   .configure(this); IRQ_STATUS   .build();
      IRQ_ENABLE   .configure(this); IRQ_ENABLE   .build();
      IRQ_FORCE    .configure(this); IRQ_FORCE    .build();
      ERR_STATUS   .configure(this); ERR_STATUS   .build();
      ERR_ENABLE   .configure(this); ERR_ENABLE   .build();
      ERR_INJECT   .configure(this); ERR_INJECT   .build();
      ERR_COUNT    .configure(this); ERR_COUNT    .build();
      ERR_INFO     .configure(this); ERR_INFO     .build();
      LOCK         .configure(this); LOCK         .build();
      SOFT_RESET   .configure(this); SOFT_RESET   .build();

      // Backdoor HDL slices matching apb_pkt_switch.sv signals
      SWITCH_CTRL .add_hdl_path_slice("switch_ctrl_q",  0, 32);
      PORT_ENABLE .add_hdl_path_slice("port_enable_q",  0, 4);
      FWD_ENABLE  .add_hdl_path_slice("fwd_enable_q",   0, 4);
      GEN_CTRL    .add_hdl_path_slice("gen_ctrl_q",     0, 32);
      GEN_PKT_CFG .add_hdl_path_slice("gen_pkt_cfg_q",  0, 32);
      GEN_INTERVAL.add_hdl_path_slice("gen_interval_q", 0, 16);
      GEN_COUNT   .add_hdl_path_slice("gen_count_q",    0, 16);
      IRQ_STATUS  .add_hdl_path_slice("irq_status_q",   0, 8);
      IRQ_ENABLE  .add_hdl_path_slice("irq_enable_q",   0, 8);
      ERR_STATUS  .add_hdl_path_slice("err_status_q",   0, 8);
      ERR_ENABLE  .add_hdl_path_slice("err_enable_q",   0, 8);
      ERR_COUNT   .add_hdl_path_slice("err_count_q",    0, 16);
      ERR_INFO    .add_hdl_path_slice("err_info_q",     0, 32);
      LOCK        .add_hdl_path_slice("locked",         0, 1);
      STAT_RX     .add_hdl_path_slice("u_sw.rx_q",      0, 16);
      STAT_TX     .add_hdl_path_slice("u_sw.tx_q",      0, 16);
      STAT_DROP   .add_hdl_path_slice("u_sw.drop_q",    0, 16);

      apb_map = create_map("apb_map", 'h0, 4, UVM_LITTLE_ENDIAN, 0);

      apb_map.add_reg(DEVICE_ID,     ADDR_DEVICE_ID,     "RO");
      apb_map.add_reg(VERSION,       ADDR_VERSION,       "RO");
      apb_map.add_reg(SWITCH_STATUS, ADDR_SWITCH_STATUS, "RO");
      apb_map.add_reg(PORT_STATUS,   ADDR_PORT_STATUS,   "RO");
      apb_map.add_reg(GEN_STATUS,    ADDR_GEN_STATUS,    "RO");
      apb_map.add_reg(STAT_RX,       ADDR_STAT_RX,       "RO");
      apb_map.add_reg(STAT_TX,       ADDR_STAT_TX,       "RO");
      apb_map.add_reg(STAT_DROP,     ADDR_STAT_DROP,     "RO");
      apb_map.add_reg(SWITCH_CTRL,   ADDR_SWITCH_CTRL,   "RW");
      apb_map.add_reg(PORT_ENABLE,   ADDR_PORT_ENABLE,   "RW");
      apb_map.add_reg(FWD_ENABLE,    ADDR_FWD_ENABLE,    "RW");
      apb_map.add_reg(GEN_CTRL,      ADDR_GEN_CTRL,      "RW");
      apb_map.add_reg(GEN_PKT_CFG,   ADDR_GEN_PKT_CFG,   "RW");
      apb_map.add_reg(GEN_INTERVAL,  ADDR_GEN_INTERVAL,  "RW");
      apb_map.add_reg(GEN_COUNT,     ADDR_GEN_COUNT,     "RW");
      apb_map.add_reg(IRQ_STATUS,    ADDR_IRQ_STATUS,    "RW");
      apb_map.add_reg(IRQ_ENABLE,    ADDR_IRQ_ENABLE,    "RW");
      apb_map.add_reg(IRQ_FORCE,     ADDR_IRQ_FORCE,     "WO");
      apb_map.add_reg(ERR_STATUS,    ADDR_ERR_STATUS,    "RW");
      apb_map.add_reg(ERR_ENABLE,    ADDR_ERR_ENABLE,    "RW");
      apb_map.add_reg(ERR_INJECT,    ADDR_ERR_INJECT,    "WO");
      apb_map.add_reg(ERR_COUNT,     ADDR_ERR_COUNT,     "RO");
      apb_map.add_reg(ERR_INFO,      ADDR_ERR_INFO,      "RO");
      apb_map.add_reg(LOCK,          ADDR_LOCK,          "RW");
      apb_map.add_reg(SOFT_RESET,    ADDR_SOFT_RESET,    "WO");

      lock_model();
    endfunction
  endclass

endpackage
